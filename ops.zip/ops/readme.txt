﻿=== On Page SEO ===
Contributors: Rishikesh Singh
Tags: On Page SEO, OPS, SEO, Keyword Search, Yoast, Keyword Rank, Robots.txt,  XML Sitemap, All In One SEO, crawler, robot, robots, search engines
Requires at least: 1.0
Tested up to: 5.7
Stable tag: /trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

On Page SEO is No #1 Plugin for allow website crawling by all Search Engine. By default wordpress is not provide robots.txt and sitemap.xml file when this plugin is add then automatically robots.txt file and sitemap.xml added and resolve this issue. On Page SEO is powerful and easy to use plugin that can added Robots.txt file and sitemap file to your wordpress website. On Page SEO WordPress Robots.txt file added automatically and optimization (+ XML Sitemap) – Website traffic, SEO & ranking Booster Plugin. It is fully optimize automatic On page SEO that is name. On page SEO is also provide noindex file creation if you want to block all crawlers for website development time.


== Description ==

Best On Page SEO Plugin for WordPress to Add Robots.txt and Sitemap.xml File in Root Directory


On Page SEO is powerful and easy to use plugin.On Page SEO make Robots.txt file was made to work with the Yoast SEO plugin (probably the best SEO Plugin for WordPress websites). It will detect if you are currently using Yoast SEO and if the sitemap feature is activated. If it is, then it will add instructions automatically into the Robots.txt file asking bots/crawlers to read your sitemap and check if you have made recent changes in your website (so that search engines can crawl the new content that is available).

 = General Features : =

 * 100% On Page SEO Rank.
 * Sutible for all kinds of WordPress sites.
 * Resolve Robots.txt Missing field in your website.
 * Also provide Disallow web crawlers.
 * Search engine visibility.
 * Yoest Sitemap detect.
 * Sitmap Create.

 = Extra Features : =

 * On page #SEO Fully Resolve.
 * Proper Robots.txt file creation. 
 * Default allow web crawlers to index all pages.
 * Simple Block Search Indexing with noindex (if you want).
 * Faster generation.
 * Discourage search engines from indexing this site.
 * Totally Free & No coding skill.
 * Lightweight only 90 KB Size.
 * No Any effect your website page speed score.

= Help : =

* If you need any help see [Plugin Website](https://plugins.wordpress.org/on-page-seo).

== Installation ==

 1. Download the plugin.
 2. Unzip the `on-page-seo` package and upload the file to your WordPress installation’s `plugins` folder.
 3. Enable the plugin by clicking activate button.
 4. Adjust any settings you want under 'On Page SEO` menu
 5. Automatically detect robots.txt file


For basic usage, you can also have a look at the [Plugin Website](https://plugins.wordpress.org/on-page-seo/).

== Frequently Asked Questions ==

= What is use of On Page SEO in Websites ? =

On Page SEO Provides automatically Robots.txt creation on WordPress website. virtual robots.txt helps you boost your website SEO (indexing capacities, Google ranking,etc.) and your loading performance – Compatible with Yoast SEO.

= Will it conflict with an existing robots.txt file? =

If a physical robots.txt file exists on your site, WordPress won’t process any request for one, so there will be no conflict.
You can generate our robots.txt rule to allow web crawer to index website.

= Where can i see robotx.txt file  =

Yes! You can see your website result. just open your website domain add /robots.txt to see live result.

= How to resolve website noindex? =

Install this plugin because this plugin is tested with this issue and automatic removed this issue in your website.

= Can I customize robots.txt file? =

Definitely, You can edit robots.txt file.

= How to change robots.txt file? =

You can edit this settings on **Dashboard >> On Page SEO >> Robots.txt File** options directly.



== Screenshots ==

1. Customize this plugin from this Setting tab like this on Page SEO settings option. That's it!

== Changelog ==

= 1.0 = 
* Hey, Update this Plugin now. New styles and light-fast robots.txt generation algorithm with schema markup, google rich snippet compatible...

